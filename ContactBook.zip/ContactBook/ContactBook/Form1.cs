﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactBook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void name_txtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void num_txtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveFileDialog1.FileName;
                string content = name_txtbox.Text + " " + num_txtbox.Text + Environment.NewLine;

                if (File.Exists(fileName))
                {
                    File.AppendAllText(fileName, content);
                }
                else
                {
                    File.WriteAllText(fileName, content);
                }

                MessageBox.Show("Contact saved to " + fileName);
            }
        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            string searchText = name_txtbox.Text;
            string fileName = "contacts.txt";

            if (File.Exists(fileName))
            {
                string[] lines = File.ReadAllLines(fileName);
                foreach (string line in lines)
                {
                    if (line.Contains(searchText))
                    {
                        MessageBox.Show("Contact found");
                        System.Diagnostics.Process.Start(fileName);
                        return;
                    }
                }
                MessageBox.Show("Contact not found");
            }
            else
            {
                MessageBox.Show("Contacts file does not exist");
            }

        }
    }
}
